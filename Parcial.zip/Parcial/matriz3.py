def es_primo(num):
    """Verifica si un número es primo."""
    if num <= 1:
        return False
    if num == 2:
        return True
    if num % 2 == 0:
        return False
    for i in range(3, int(num**0.5) + 1, 2):
        if num % i == 0:
            return False
    return True

def llenar_matriz():
    """Llena una matriz 5x5 con números primos ingresados por el usuario."""
    matriz = []
    
    print("Por favor, ingrese 25 números primos para llenar una matriz de 5x5.")
    
    for i in range(5):
        fila = []
        for j in range(5):
            while True:
                try:
                    numero = int(input(f"Introduce el número primo para la posición ({i+1},{j+1}): "))
                    if es_primo(numero):
                        fila.append(numero)
                        break
                    else:
                        print("El número ingresado no es primo. Por favor, introduce un número primo.")
                except ValueError:
                    print("Por favor, introduce un número entero válido.")
        
        matriz.append(fila)
    
    return matriz

matriz_primos = llenar_matriz()

print("\nLa matriz 5x5 llena de números primos es:")
for fila in matriz_primos:
    print(fila)