numeros_impares = []


for i in range(10):
    while True:
        try:
            
            numero = int(input(f"Introduce el número {i+1}: "))
            
            if numero % 2 != 0:
                
                numeros_impares.append(numero)
            break
        except ValueError:
            print("Por favor, introduce un número entero válido.")

# Mostrar los números impares almacenados
print("Los números impares ingresados son:", numeros_impares)