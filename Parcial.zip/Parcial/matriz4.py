def llenar_matriz_z(tamaño):
    """Llena una matriz de tamaño `tamaño` x `tamaño` con la letra 'Z'."""
    matriz = []
    for i in range(tamaño):
        fila = ['Z'] * tamaño
        matriz.append(fila)
    return matriz


tamaño_matriz = 9


matriz_z = llenar_matriz_z(tamaño_matriz)


print("\nLa matriz 9x9 llena de la letra 'Z' es:")
for fila in matriz_z:
    print(' '.join(fila))