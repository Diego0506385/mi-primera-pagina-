numeros_pares = []


numero = 2


while len(numeros_pares) < 5:
    numeros_pares.append(numero)
    numero += 2  

# Imprimir la lista de números pares
print("Lista de números pares:", numeros_pares)